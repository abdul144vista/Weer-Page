
// var img = document.querySelector("body");
// console.log(img)
// img.style.backgroundImage = "url(img/snow.gif)"
// console.log(data)

// if (data == 'clear Sky') {
//     img.style.backgroundImage = "url(img/Clearsky.gif)"
// } else if (data == 'broken clouds'){
//     img.style.backgroundImage = "url(img/brokenclouds.gif)"
// } else if (data == 'mist') {
//     img.style.backgroundImage = "url(img/mist.gif)"
// } else if (data == 'light rain') {
//     img.style.backgroundImage = "url(img/Rain.gif)"
// } else if (data == 'scatteredc louds') {
//     img.style.backgroundImage = "url(img/scatteredclouds.gif)"
// } else if (data == 'shower rain') {
//     img.style.backgroundImage = "url(img/showerrain.gif)"
// } else if (data == 'snow') {
//     img.style.backgroundImage = "url(img/snow.gif)"
// } else if (data == 'thunderstorm' ) {
//     img.style.backgroundImage = "url(img/thunderstorm.gif)"
// } else {
//     img.style.backgroundImage ="url(img/snow.gif)"
// }







var img = document.querySelector("body");
weather = document.getElementById('weather-forecast')
console.log(weather)


switch (img.weather[0].description) {
    case "clouds":
        document.getElementById("weather-forecast").style.backgroundImage = "url(img/clouds.gif)";
        break;
        case "mist":
        document.getElementById("weather-forecast").style.backgroundImage = "url(img/mist.gif)";
        break;
        case "rain":
        document.getElementById("weather-forecast").style.backgroundImage = "url(Rain.gif)";
        break;
        case "snow":
        document.getElementById("weather-forecast").style.backgroundImage =  "url(img/Snow.gif)";
        break;
        case "thunderstrom":
        document.getElementById("weather-forecast").style.backgroundImage = "url(img/thunderstrom.gif)";
        break;
        case "Clear":
        document.getElementById("weather-forecast").style.backgroundImage = "url(img/Clear.gif)";
        break;
        default:
        
}
