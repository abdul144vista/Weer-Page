const timeEl = document.getElementById('time');
const dateEl = document.getElementById('date');
const timezone = document.getElementById('time-zone');
const weatherForecastEl = document.getElementById('weather-forecast');
const currentTempEl = document.getElementById('current-temp');
const data = getWeatherData();
const days = ['Zondag', 'Maandag', 'Dinsdag', 'Woensdag', 'Donderdag', 'Vrijdag', 'Zaterdag']
const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dec']
const API_KEY ='49cc8c821cd2aff9af04c9f98c36eb74'
setInterval(() => {
    const time = new Date();
    const month = time.getMonth();
    const date = time.getDate();
    const day = time.getDay();
    const hour = time.getHours();
    const hoursIn24HrFormat = hour >= 24 ? hour %24: hour;
    const minutes = time.getMinutes();
    timeEl.innerHTML = (hoursIn24HrFormat < 10? '0'+hoursIn24HrFormat : hoursIn24HrFormat)  + ':' + (minutes < 10? '0'+minutes : minutes)+ ' Uur '  
    dateEl.innerHTML = days[day] + ', ' + date+ ' ' + months[month]

}, 1000);

function getWeatherData () {
    navigator.geolocation.getCurrentPosition((success) => {
        
        let {latitude, longitude } = success.coords;

        fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latitude}&lon=${longitude}&exclude=hourly,minutely&units=metric&appid=${API_KEY}&lang={nl}`).then(res => res.json()).then(data => {

        console.log(data)
        showWeatherData(data);
        })

    })
}

 
    function showWeatherData (data){

    timezone.innerHTML = data.timezone;

    let otherDayForcast = ''
    data.daily.forEach((day, idx) => {
        if(idx == 0){
            currentTempEl.innerHTML = `
            <img src="http://openweathermap.org/img/wn//${main = data.current.weather[0].icon}@4x.png" alt="weather icon" class="w-icon">
            <div class="other">
               <div class="dag">${window.moment(day.dt*1000).format('dddd')}</div>
               <div class="temp">${main = data.current.temp} °C</div>
               <div class="weather">${main = data.current.weather[0].main}</div>
               </div>
            `
        }else{
            otherDayForcast += `
            <div class="weather-forecast-item">
               <div class="dag">${window.moment(day.dt*1000).format('ddd')}</div>
                <img src="http://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="weather icon" class="w-icon">
                <div class="temp">  ${day.temp.day} °C</div>
                <div class="weather">${day.weather[0].main}</div>
            </div>

            `
        }
    })

   
    weatherForecastEl.innerHTML = otherDayForcast;

    

    console.log(main = data.current.weather[0].main)
    switch (main = data.current.weather[0].main) {
        case "Clouds":
            document.getElementById("wrapper-bg").style.backgroundImage = "url(img/clouds.gif)";
            break;
            case "Mist":
            document.getElementById("wrapper-bg").style.backgroundImage = "url(img/mist.gif)";
            break;
            case "Drizzle":
            document.getElementById("wrapper-bg").style.backgroundImage = "url(img/Drizzle.gif)";
            break;
            case "Snow":
            document.getElementById("wrapper-bg").style.backgroundImage =  "url(img/Snow.gif)";
            break;
            case "Thunderstrom":
            document.getElementById("wrapper-bg").style.backgroundImage = "url(img/thunderstorm.gif)";
            break;
            case "Clear":
            document.getElementById("wrapper-bg").style.backgroundImage = "url(img/Clear.gif)";
            break;   
            case "Rain":
            document.getElementById("wrapper-bg").style.backgroundImage = "url(img/Rain.gif)";
            break;   
            default:
    }
    
}


